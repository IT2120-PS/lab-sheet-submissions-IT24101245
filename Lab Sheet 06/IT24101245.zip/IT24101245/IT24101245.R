setwd("C:\\Users\\asus_pc\\Desktop\\IT24101245")
getwd()

dbinom(40,44,0.92)

pbinom(35,44,0.92,lower.tail=TRUE)
1- pbinom(37,44,0.92,lower.tail=TRUE)
pbinom(37,44,0.92,lower.tail=FALSE)
pbinom(42,44,0.92,lower.tail=TRUE)-pbinom(39,44,0.92,lower.tail=TRUE)

dpois(6,5)
ppois(6,5,lower.tail=FALSE)


#Exercise
#Q1
#X~Binomial(n=50, p=0.85).
pbinom(46, size=50, prob=0.85, lower.tail=FALSE)

#Q2
#X=count of calls in an hour.
#X~Poisson(λ=12).
dpois(15, lambda=12)
s