setwd("C:\\Users\\asus_pc\\Desktop\\IT24101245")
getwd()

#Exercise
delivery_data <- read.table("Exercise - Lab 05.txt", header=TRUE)
names(delivery_data) <- c("Delivery_Time")
attach(delivery_data)

histogram <- hist(Delivery_Time,
                  main="Histogram of Delivery Times",
                  xlab="Delivery Time (minutes)",
                  ylab="Frequency",
                  breaks=seq(20, 70, length.out=10))

cum_freq <- cumsum(histogram$counts)
breaks <- histogram$breaks
ogive_y <- c(0, cum_freq)

plot(breaks, ogive_y,
     type="l",
     main="Cumulative Frequency Polygon (Ogive)",
     xlab="Delivery Time (minutes)",
     ylab="Cumulative Frequency")



