setwd("C:\Users\asus_pc\Desktop\IT24101245")
getwd()

#i
## Null Hypothesis (H0): Customers choose the four snack types (A, B, C, D) with equal probability, i.e., pA = pB = pC = pD = 0.25.
# Alternative Hypothesis (H1): The probabilities for choosing the snack types are not all equal.

#ii
observed <- c(120, 95, 85, 100)
chisq.test(observed)

#iii