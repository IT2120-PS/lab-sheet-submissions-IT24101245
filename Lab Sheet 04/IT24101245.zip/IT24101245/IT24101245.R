setwd("C:\\Users\\IT24101245\\Desktop\\IT24101245")

#Exercise
branch_data <- read.table("Exercise.txt", header=TRUE)

str(branch_data)

boxplot(branch_data$sales,main="Sales Distribution")

summary(branch_data$advertising)
IQR(branch_data$advertising)

find_outliers<-function(x){
  Q1 <- quantile(x,0.25)
  Q3 <- quantile(x,0.75)
  IQR <- Q3-Q1
  lower <- Q1 - 1.5*IQR
  upper <- Q3 + 1.5*IQR
  outliers <- x[x<lower | x>upper]
  return(outliers)
}
find_outliers(branch_data$years)
